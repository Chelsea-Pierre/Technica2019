package technica;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student("Josie Kaufman", 1234567890, "University of Maryland");
		String result = s1.toString();
		System.out.println(result);
		
		Assignment a1 = new Assignment("CMNS132", "Java Project", "11/9/2019", 20, AssignmentType.PROGRAMMING_PROJECT, false);
		String result2 = a1.toString();
		System.out.println(result2);
		
		Assignment a2 = new Assignment("Calculus 3", "Math homework", "11/10/2019", 10, AssignmentType.MATH_HOMEWORK, false);
		String result3 = a2.toString();
		System.out.println(result3);
		
		Assignment a3 = new Assignment("Biology", "Cell Essay", "2/10/2020", 5, AssignmentType.ESSSAY, true);
		String result4 = a3.toString();
		System.out.println(result4);
		
		Assignment a4 = new Assignment("Chemistry", "Atom Presentation", "3/4/2020", 30, AssignmentType.PRESENTATION, false);
		String result5 = a4.toString();
		System.out.println(result5);
		
		System.out.println("Completed Assignments: " + "Cell Essay");
		System.out.println("Todo List: " + "Java Project, " + "Math Homework, " + "Atom Presentation");
		System.out.println("Maximum productivity order: " + "Atom Presentation, " + "Math homework, " + "Java Project");

	}

}
