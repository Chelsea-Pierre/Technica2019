package technica;

import java.util.ArrayList;
import java.util.Calendar;

public class ClassTask /*extends Assignment*/ implements Manage/*, Comparable<Assignment>*/ {
	
//	public ClassTask(String className, String assignmentName, String DEFAULT_DUEDATE_FORMAT, int assignmentWeight,
//			AssignmentType type, boolean completed) {
//		super(className, assignmentName, DEFAULT_DUEDATE_FORMAT, assignmentWeight, type, completed);
//		
//	}

	/*Time to complete assignment in minutes*/

	private Calendar now = Calendar.getInstance();
    private ArrayList <Assignment> assignmentList = new ArrayList<Assignment>();

    public void addStudent(String name, int studentId, String university){
        Student student = new Student(name, studentId, university);
    }
    public void addAssignment(Assignment assignment){
        assignmentList.add(assignment);
    }
    
   

	
	
	

}
