package technica;

import java.util.Arrays;
import java.util.Comparator;

public class Assignment implements Comparable<Assignment>{
	private String className;
    private String assignmentName;
    private String DEFAULT_DUEDATE_FORMAT = "MM/dd/yyyy";
    private int assignmentWeight;
    private AssignmentType type;
    private boolean completed = false;
    private int minutesToComplete = 0;

    /*Assignment constructor*/
    public Assignment(String className, String assignmentName, String DEFAULT_DUEDATE_FORMAT,
                      int assignmentWeight, AssignmentType type, boolean completed){
        this.className = className;
        this.assignmentName = assignmentName;
        this.DEFAULT_DUEDATE_FORMAT = DEFAULT_DUEDATE_FORMAT;
        this.assignmentWeight = assignmentWeight;
        this.type = type;
        this.completed = completed;

    }
    public int calculateTime(AssignmentType type){
        if (type == AssignmentType.ESSSAY){
            minutesToComplete = 60;
        }
        else if(type == AssignmentType.PROGRAMMING_PROJECT){
            minutesToComplete = 180;
        }
        else if(type == AssignmentType.PRESENTATION){
            minutesToComplete = 240;
        }
        else if(type == AssignmentType.MATH_HOMEWORK){
            minutesToComplete = 30;
        }
        else if(type == AssignmentType.READ_ARTICLE){
            minutesToComplete = 15;
        }
        else{
            
        }
		return minutesToComplete;
    }

    public String getClassName() {
        return className;
    }
    public String getAssignmentName(){
        return assignmentName;
    }
    public String getDate() {
    	return DEFAULT_DUEDATE_FORMAT;
    }

    public int getAssignmentWeight() {
        return assignmentWeight;
    }
    public AssignmentType getAssignmentType() {
    	return type;
    }
    public int getTimeToComplete(AssignmentType type) {
    	return calculateTime(type);
    }

    public boolean getCompleted() {
        return completed;
    }
    
    @Override
	public int compareTo(Assignment o) {
		int compareTime = ((Assignment) o).getTimeToComplete(this.type);
		return compareTime - this.getTimeToComplete(this.type);
		
	}
	public  Comparator<Assignment> FruitNameComparator = new Comparator<Assignment>() {
		

		public int compare(Assignment a1, Assignment a2) {
			
			int first = a1.getTimeToComplete(type);
			int second = a2.getTimeToComplete(type);
			return second - first;
		
			//descending order
			
			//return second.compareTo(first);
		}

	};
    
    public String toString(){
        String toRet = "";
        		toRet += "Class name: " + className + "\nAssignment Name: " + assignmentName +
        		"\nDate due: " + DEFAULT_DUEDATE_FORMAT+
                "\nAssignment Weight: " + assignmentWeight + "% of " + className +
                " grade" + "\nAssignment Type: " + type + "\nAssignment completed? " + completed + 
                "\nExpected minutes to complete: " + getTimeToComplete(this.type);
        		return toRet;

    }
    

}
